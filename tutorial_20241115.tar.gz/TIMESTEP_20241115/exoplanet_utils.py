import os

import numpy as np
import pandas as pd


def mass_from_K(K, P, mstar=1.0, ecc=0.0, units='ms'):
    
    msun=1.9885e33
    mearth=5.97236e27
    G=6.67408e-8
    
    fnc = (2*np.pi*G)**(1./3.)*(mstar*msun)**(-2./3.)*(P*86400)**(-1./3.)/np.sqrt(1-ecc**2)/100.
    
    mp = K / fnc / mearth
    
    return mp # Earth masses


def get_exoplanet_demographics(method='Radial Velocity'):
    
    archive = pd.read_csv(os.path.join('SampleData','PS_2024.11.14_20.01.03.csv'), skiprows=100)
    
    args = np.where(archive.discoverymethod==method)[0]
    
    periods = archive.pl_orbper[args]
    
    masses = archive.pl_bmasse[args]
    
    return periods, masses